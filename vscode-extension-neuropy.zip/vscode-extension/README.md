# NeuroPy — Extensión para VS Code

**LogLabs · v0.3.0**

Soporte completo del lenguaje NeuroPy en Visual Studio Code.

---

## Características

- **Syntax highlighting** completo para `.npy` y `.ny`
- **Snippets** para todos los bloques del lenguaje
- **Tema NeuroPy Dark** optimizado para el lenguaje
- **Hover docs** — pasa el cursor sobre cualquier palabra clave para ver su descripción
- **Validación de cabecera** — alerta si falta `#NeuroPy <neuron>`
- **Ejecutar archivos** — botón ▶ en la barra de título o `Ctrl+Shift+N`
- **REPL integrado** — abre el intérprete directamente en el terminal

---

## Instalación manual (sin marketplace)

1. Copia la carpeta `vscode-extension/` a:
   - **Windows:** `%USERPROFILE%\.vscode\extensions\neuropy-0.3.0`
   - **Mac/Linux:** `~/.vscode/extensions/neuropy-0.3.0`
2. Reinicia VS Code
3. Abre cualquier archivo `.npy` o `.ny`

---

## Snippets disponibles

| Prefijo       | Descripción                          |
|---------------|--------------------------------------|
| `header`      | Cabecera `#NeuroPy <neuron>`         |
| `create`      | Bloque `create LLM { }`             |
| `start`       | Bloque `start create ... end`        |
| `window`      | App de chat con ventana gráfica      |
| `terminal`    | Chat en consola                      |
| `ofm`         | Bloque Open For Model                |
| `var`         | `var nombre = valor`                 |
| `const`       | `const NOMBRE = valor`               |
| `if`          | Condicional `if`                     |
| `ifelse`      | Condicional `if / else`              |
| `while`       | Bucle `while`                        |
| `for`         | Bucle `for...in`                     |
| `func`        | Declarar función                     |
| `print`       | `print("...")`                       |
| `plot`        | `plot loss, accuracy`                |
| `full`        | Script completo de entrenamiento     |

---

## Configuración

En `settings.json`:

```json
{
  "neuropy.autoValidate": true,
  "neuropy.formatOnSave": false,
  "neuropy.interpreterPath": "/ruta/a/neuropy_core.py"
}
```

---

## Atajos de teclado

| Atajo           | Acción                    |
|-----------------|---------------------------|
| `Ctrl+Shift+N`  | Ejecutar archivo .npy     |
| `Ctrl+Space`    | Activar snippets          |

---

**LogLabs** — Hecho para hacer IA accesible.
