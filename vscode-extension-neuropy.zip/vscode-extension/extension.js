// extension.js — NeuroPy VS Code Extension
// LogLabs · v0.3.0

const vscode = require('vscode');
const path   = require('path');
const cp     = require('child_process');

function activate(context) {
    console.log('[NeuroPy] Extensión activada.');

    // ── Comando: Ejecutar archivo .npy ─────────────────────────────
    const runCmd = vscode.commands.registerCommand('neuropy.runFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('NeuroPy: No hay archivo activo.');
            return;
        }

        const filePath = editor.document.fileName;
        const ext = path.extname(filePath).toLowerCase();

        if (ext !== '.npy' && ext !== '.ny') {
            vscode.window.showWarningMessage(
                `NeuroPy: El archivo debe tener extensión .npy o .ny (tienes: ${ext})`
            );
            return;
        }

        // Guardar antes de ejecutar
        editor.document.save().then(() => {
            const config = vscode.workspace.getConfiguration('neuropy');
            const interpreterPath = config.get('interpreterPath', '');

            let command;
            if (interpreterPath) {
                command = `python3 "${interpreterPath}" "${filePath}"`;
            } else {
                // Intentar usar el comando neuropy del PATH
                command = `neuropy "${filePath}"`;
            }

            // Abrir terminal integrada y ejecutar
            let terminal = vscode.window.terminals.find(t => t.name === 'NeuroPy');
            if (!terminal) {
                terminal = vscode.window.createTerminal({
                    name: 'NeuroPy',
                    iconPath: new vscode.ThemeIcon('sparkle'),
                });
            }
            terminal.show();
            terminal.sendText(command);
        });
    });

    // ── Comando: Abrir REPL ────────────────────────────────────────
    const replCmd = vscode.commands.registerCommand('neuropy.openRepl', () => {
        const config = vscode.workspace.getConfiguration('neuropy');
        const interpreterPath = config.get('interpreterPath', '');
        const command = interpreterPath
            ? `python3 "${interpreterPath}"`
            : 'neuropy';

        let terminal = vscode.window.terminals.find(t => t.name === 'NeuroPy REPL');
        if (!terminal) {
            terminal = vscode.window.createTerminal({ name: 'NeuroPy REPL' });
        }
        terminal.show();
        terminal.sendText(command);
    });

    // ── Validación de cabecera al abrir/guardar ────────────────────
    const validateHeader = (document) => {
        if (document.languageId !== 'neuropy') return;
        const config = vscode.workspace.getConfiguration('neuropy');
        if (!config.get('autoValidate', true)) return;

        const firstLine = document.lineAt(0).text.trim();
        const headerPattern = /^#NeuroPy\s+<\w+>/;

        const diagnostics = [];
        if (!headerPattern.test(firstLine)) {
            const range = new vscode.Range(0, 0, 0, firstLine.length || 1);
            const diag  = new vscode.Diagnostic(
                range,
                'NeuroPy: El archivo debe comenzar con  #NeuroPy <neuron>',
                vscode.DiagnosticSeverity.Error
            );
            diag.source = 'NeuroPy';
            diagnostics.push(diag);
        }

        diagnosticCollection.set(document.uri, diagnostics);
    };

    const diagnosticCollection = vscode.languages.createDiagnosticCollection('neuropy');
    context.subscriptions.push(diagnosticCollection);

    // Validar al abrir
    context.subscriptions.push(
        vscode.workspace.onDidOpenTextDocument(validateHeader)
    );

    // Validar al guardar
    context.subscriptions.push(
        vscode.workspace.onDidSaveTextDocument(doc => {
            validateHeader(doc);
            if (doc.languageId === 'neuropy') {
                const config = vscode.workspace.getConfiguration('neuropy');
                if (config.get('formatOnSave', false)) {
                    vscode.commands.executeCommand('editor.action.formatDocument');
                }
            }
        })
    );

    // Validar documentos ya abiertos al activar
    vscode.workspace.textDocuments.forEach(validateHeader);

    // ── Status Bar ─────────────────────────────────────────────────
    const statusBar = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Left, 100
    );
    statusBar.command = 'neuropy.runFile';
    statusBar.tooltip = 'NeuroPy: Ejecutar archivo (Ctrl+Shift+N)';
    context.subscriptions.push(statusBar);

    const updateStatusBar = (editor) => {
        if (editor && ['neuropy'].includes(editor.document.languageId)) {
            statusBar.text    = '$(sparkle) NeuroPy';
            statusBar.color   = '#7F77DD';
            statusBar.show();
        } else {
            statusBar.hide();
        }
    };

    context.subscriptions.push(
        vscode.window.onDidChangeActiveTextEditor(updateStatusBar)
    );
    updateStatusBar(vscode.window.activeTextEditor);

    // ── Hover Provider ─────────────────────────────────────────────
    const hoverProvider = vscode.languages.registerHoverProvider('neuropy', {
        provideHover(document, position) {
            const range = document.getWordRangeAtPosition(position);
            if (!range) return;
            const word = document.getText(range);

            const docs = {
                'create': '**create** `tipo { }` — Define un modelo, app o componente de NeuroPy.',
                'start':  '**start create** `tipo ( ) end` — Ejecuta e inicia lo definido en create.',
                'ofm':    '**ofm** `Lib.lib( )` — *Open For Model*. Bloque de instrucciones para el modelo.',
                'import': '**import** `%Lib%.lib` — Importa una librería o modelo `.gguf`.',
                'optimizer': '**optimizer** — Algoritmo de optimización. Ej: `Adam(lr=0.001)`, `SGD`, `AdamW`.',
                'loss':   '**loss** — Función de pérdida. Ej: `categorical_crossentropy`, `mse`, `mae`.',
                'epochs': '**epochs** — Número de épocas de entrenamiento.',
                'batch':  '**batch** — Tamaño del batch.',
                'metric': '**metric** — Métrica(s) a registrar. Ej: `accuracy`, `f1`, `precision`.',
                'device': '**device** — Dispositivo. `cpu` | `gpu` | `auto`.',
                'plot':   '**plot** `metrica1, metrica2` — Grafica métricas de entrenamiento.',
                'print':  '**print**`("texto")` — Imprime en la consola.',
                'var':    '**var** `nombre = valor` — Variable mutable.',
                'const':  '**const** `NOMBRE = valor` — Constante inmutable.',
                'func':   '**func** `nombre(params) { }` — Declara una función.',
                'if':     '**if** `condicion { }` — Condicional.',
                'while':  '**while** `condicion { }` — Bucle mientras la condición sea verdadera.',
                'for':    '**for** `item in coleccion { }` — Itera sobre una colección.',
                'window': '**window** — Crea o configura una ventana gráfica.',
                'into':   '**into( )** — Bloque de contenido interior de una ventana.',
                'send':   '**send**`(imf"Modelo")` — Envía el input del usuario al modelo.',
                'response': '**response**`(@)` — Captura la respuesta del modelo en `@`.',
                'connect': '**connect to** `destino` — Conecta el output a una ventana o consola.',
                'prompt': '**prompt** `Lib.lib("texto")` — Define el prompt del terminal (default: "Syntax >")',
            };

            if (docs[word]) {
                return new vscode.Hover(new vscode.MarkdownString(docs[word]));
            }
        }
    });

    context.subscriptions.push(runCmd, replCmd, hoverProvider);

    // ── Mensaje de bienvenida ──────────────────────────────────────
    vscode.window.showInformationMessage(
        '$(sparkle) NeuroPy activado — LogLabs v0.3.0',
        'Abrir REPL'
    ).then(choice => {
        if (choice === 'Abrir REPL') {
            vscode.commands.executeCommand('neuropy.openRepl');
        }
    });
}

function deactivate() {
    console.log('[NeuroPy] Extensión desactivada.');
}

module.exports = { activate, deactivate };
